#!/usr/bin/env bash

roslaunch t265_d435 vizualizer.launch
